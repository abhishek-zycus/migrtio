package com.project.backend.service;

import com.project.backend.entity.ProductEntity;
import com.project.backend.repository.ProductRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

  @Autowired
  private ProductRepository repository;

  public ProductEntity saveProduct(ProductEntity product) {
    return repository.save(product);
  }

  public List<ProductEntity> saveProductList(List<ProductEntity> producList) {
    return repository.saveAll(producList);
  }

  public List<ProductEntity> getProductList() {
    return repository.findAll();
  }

  public ProductEntity getProductById(Long id) {
    return repository.findById(id).orElse(null);
  }

  public ProductEntity getProductByName(String name) {
    return repository.findByName(name);
  }

  public String deteleProduct(Long id) {
    repository.deleteById(id);
    return "deleted product- " + id;
  }

  public ProductEntity updateProduct(ProductEntity updatedProduct) {
    ProductEntity product = repository
      .findById(updatedProduct.getId())
      .orElse(null);
    product.setName(updatedProduct.getName());
    product.setPrice(updatedProduct.getPrice());
    product.setQuantity(updatedProduct.getQuantity());
    return repository.save(product);
  }
}
