package com.project.backend.entity;

import jakarta.persistence.*;
import jdk.jfr.Enabled;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="CATEGORY_TBL")
public class CategoryEntity {

    @Id
    @GeneratedValue
    private Long categoryId;

    private  String categoryName;

    @ManyToMany(mappedBy = "category", cascade = CascadeType.ALL)
    private List<ProductEntity> product = new ArrayList<ProductEntity>();
}