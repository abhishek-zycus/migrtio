package com.project.backend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "PRODUCT_TBL")
@AllArgsConstructor
@NoArgsConstructor
public class ProductEntity {

  @Id
  @GeneratedValue
  private Long id;

  // @Column(nullable = false)
  private String name;
  private int price;
  private int quantity;

  @ManyToMany()
  private List<CategoryEntity> category = new ArrayList<CategoryEntity>();
}
